# Imprimir un mensaje en la consola
print("¡Hola, mundo!")

# Declarar variables de diferentes tipos y realizar operaciones
edad = 30
altura = 1.75
nombre = "Juan"

print("Mi nombre es", nombre, "tengo", edad, "años y mido", altura, "metros.")

# Concatenar cadenas
saludo = "Hola, mi nombre es " + nombre
print(saludo)

# Pedir un dato al usuario
numero_favorito = int(input("¿Cuál es tu número favorito? "))
print("Tu número favorito es el", numero_favorito)
